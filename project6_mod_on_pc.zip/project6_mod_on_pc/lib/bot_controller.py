import telebot
bot = telebot.TeleBot('5659103924:AAGC1xgY7Yhc8veSfK0-NgdP093rxykOMM8')
@bot.message_handler(commands=["start"])
def start(m, res=True):
    bot.send_message(m.chat.id, 'Я на связи. Напиши мне что-нибудь )')
@bot.message_handler(content_types=["text"])
def handle_text(message):
    print("++++++++++++++++++++++++++++")
    print("ID: " + str(message.from_user.id) + " " + "first name: " + message.from_user.first_name + " " + "MESSAGE: " + message.text)
    print("++++++++++++++++++++++++++++")
    cli = input("command_ ")
    if cli == "send_text":
        chat_id_text = input("chat id to send_ ")
        sending_text = input("text to send_ ")
        bot.send_message(chat_id_text, sending_text)
    if cli == "send_photo":
        chat_id_photo = input("chat id to send_ ")
        photo_url = input("photo url_ ")
        caption_photo = input("caption photo_ ")
        bot.send_photo(message.chat.id, photo=photo_url, caption='It works!')
bot.polling(none_stop=True, interval=0)