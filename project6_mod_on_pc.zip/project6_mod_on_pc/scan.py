import os
print(os.listdir('lib'))