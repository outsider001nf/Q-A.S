#++++++++++++VARIABLES_AND_ARRAYS
users = ["root", "guest"]
selected_user = "none"
passwd = "jack20131"
log_func = False
motd_file = False
lib_folder = False
telebot_is_on = False
#++++++++++++VARIABLES_AND_ARRAYS_END
#????????????WRITED_MODULES_ZONE
try:
  from lib import *
  lib_folder = True
except ModuleNotFoundError:
  def red_text(text):
    print("\033[31m {}" .format(text))
  print(red_text("'lib' folder is not found"))
import datetime
now = datetime.datetime.now()
import threading
import os
import platform
try:
  import telebot
  telebot_is_on = True
except ModuleNotFoundError:
  def red_text(text):
    print("\033[31m {}" .format(text)) 
  print(red_text("'PyTelegramBotApi' is not installed"))
  telebot_is_on = False
this_os = platform.system()
#????????????WRITED_MODULES_ZONE_END
#!!!!!!!!!!!!FUNCTION_CLASSES_ZONE
def reg_user():
	type_pass = input("Enter password for 'root'_ ")
	if type_pass == passwd:
		name_of_user = input("Enter the name for new user_ ")
		name_of_user = users.append(users)
		wn_strt_on_new = input("Wanna start on created user?_ ")
		if wn_strt_on_new == "y":
			selected_user = name_of_user
		if wn_strt_on_new == "n":
			selected_user = "guest"
def scan():
  scan = open("scan.py", "w")
  scan.write("import os\nprint(os.listdir('lib'))")
  scan.close()
  os.system("python scan.py > scan_result.txt")
def purple_text(text):
  print("\033[35m {}" .format(text))
def green_text(text):
  print("\033[32m {}" .format(text))
#!!!!!!!!!!!!FUNCTION_CLASSES_ZONE_END
try:
  motd = open("txt/motd.txt", "r")
  motd_file = True
  print(purple_text(motd.read()))
  motd.close()
except FileNotFoundError:
  def red_text(text):
    print("\033[31m {}" .format(text)) 
  print(red_text("'motd' file not found"))
try:
  start_time = open("log/started_log.txt", "w")
  start_time.write(now.strftime("Started on: %H:%M:%S on %A, %B the %dth, %Y"))
  start_time.close()
  log = open("log/inp_log.txt", "w")
  log_func = True
except FileNotFoundError:
  log_func = False
  def red_text(text):
    print("\033[31m {}" .format(text)) 
  print(red_text("log function is unreachable"))
#write scanner of installed cli_applicaton
if lib_folder == True:
  print(green_text("'lib' folder connected"))
  scan()
  if motd_file == True:
    print(green_text("'motd' file is enabled"))
    if log_func == True:
      print(green_text("log function is enabled"))
#ENTERING IN SYSTEM
print(users)
now_user = input("Please, enter in system_ ")
if now_user == "root":
  type_pass_ex = input("Enter password for root_ ")
  if type_pass_ex == passwd:
    selected_user = now_user
if now_user == "guest":
  selected_user = now_user
#MAYBE YOU ALREADY ENTERED?
while True:  #INTERACTIVE PART
  scan_result = open("scan_result.txt", "r")
  usr_inp = input(selected_user +"@Q-A.S--> ")
  if log_func == True:
    log.write(now.strftime("%H:%M:%S on %A, %B the %dth, %Y: " + usr_inp + "\n"))
  if usr_inp == "exit":
    if log_func == True:
      log.close()
    if this_os == "Linux":
      os.system("clear")
    break
  if usr_inp == "reboot_lib_view":
    scan()
  if usr_inp == "bot" and telebot_is_on == True:
    bot = telebot.TeleBot('5659103924:AAGC1xgY7Yhc8veSfK0-NgdP093rxykOMM8')
    @bot.message_handler(commands=["start"])
    def start(m, res=True):
      bot.send_message(m.chat.id, 'Я на связи. Напиши мне что-нибудь )')
    @bot.message_handler(content_types=["text"])
    def handle_text(message):
      print("++++++++++++++++++++++++++++")
      print("ID: " + str(message.from_user.id) + " " + "first name: " + message.from_user.first_name + " " + "MESSAGE: " + message.text)
      print("++++++++++++++++++++++++++++")
      cli = input("command_ ")
      if cli == "send_text":
          chat_id_text = input("chat id to send_ ")
          sending_text = input("text to send_ ")
          bot.send_message(chat_id_text, sending_text)
      if cli == "send_photo":
          chat_id_photo = input("chat id to send_ ")
          photo_url = input("photo url_ ")
          caption_photo = input("caption photo_ ")
          bot.send_photo(message.chat.id, photo=photo_url, caption=caption_photo)
    bot.polling(none_stop=True, interval=0)
  if usr_inp == "date":
    print("---------------------------------------------")
    print("Current date and time: ")
    print(now.strftime('%Y-%m-%d %H:%M:%S'))
    print(now.strftime('%H:%M:%S on %A, %B the %dth, %Y'))
    print("---------------------------------------------")
  if usr_inp == "started_on?":
    print("------------------------------------")
    if log_func == True:
      started_log = open("log/started_log.txt", "r")
      print(started_log.read())
      started_log.close()
    if log_func == False:
      print("log function is unreachable")
    print("------------------------------------")
  if usr_inp == "show_ip":
    if this_os == "Linux":
      os.system("ifconfig")
    if this_os == "Windows":
      os.system("ipconfig")
  if usr_inp in scan_result.read():
    os.system("cd lib && python " + usr_inp)
