import os
import threading
import socket
import colorama
from colorama import Fore, Back, Style
from playsound import playsound
from time import sleep
import datetime
host = "127.0.0.1"
port = 9090

#SOME FUNCTIONS

def count_():
    count = "0"
    runtime = open("part1-4-50-64/runtime.txt")
    while True:
        count = count + "1"
        sleep(1)
        runtime.write(count)

#END OF THIS LIST

print(Fore.BLACK + Back.RED + "!THIS IS BETA VERSION OF PROGRAM!" + Style.RESET_ALL)
os.system("cd part1-4-50-64 && python mem_core1.py")
file = open("part2-4-50-64/motd.txt")
print("\033[35m" + file.read())
print("\033[0m")
file.close()
runtime = threading.Thread(target=count_)
runtime.start()
inputreading = open("part1-4-50-64/memory_file2.txt", "w")
while True:
    usrinp = input("QAS<-user~_ ")
    inputreading.write(usrinp + "\n")
    if usrinp == "exit":
        print("Quiting...")
        sleep(1)
        try:
            os.system("clear")
        except:
            print("CAN'T CLEAR SCREEN")
        break
    if usrinp == "date":
        now = datetime.datetime.now()
        print("Current date and time: ")
        print(now.strftime('%Y-%m-%d %H:%M:%S'))
        print(now.strftime('%H:%M:%S on %A, %B the %dth, %Y'))
    if usrinp == "math":
        choise = input("1. Factorial \n2. Basic_calc \nReading input_ ")
        if choise == "1":
            def factorial(n):
                if n <= 1:
                    return n
                else:
                    return n * factorial(n - 1)
            n = int(input("Enter number_ "))
            print("Factorial of this number is: ")
            print(factorial(n))
        if choise == "2":
            def main():
                while True:

                    print("1. + \n2. - \n3. * \n4. /")
                    action = input("What you want to do?_ ")
                    if action == "q":
                        break
                    if action in ('+', '-', '*', '/'):
                        x = float(input("Enter the number(x)_ "))
                        y = float(input("Enter the number(y)_ "))
                        if action == "+":
                            print('%.2f + %.2f = %.2f' % (x, y, x+y))
                        elif action == "-":
                            print('%.2f - %.2f = %.2f' % (x, y, x-y))
                        elif action == "*":
                            print('%.2f * %.2f = %.2f' % (x, y, x*y))
                        elif action == "/":
                            if y != "0":
                                print('%.2f / %.2f = %.2f' % (x, y, x/y))
                            else:
                                print("!!!ERROR!!!")
            main()
    if usrinp == "--version":
        print("VERSION: 5.0")
    if usrinp == "open_log":
        print("===================")
        os.system("cd part1-4-50-64 && python  mem_core1.py")
        print("===================")
    if usrinp == "whoareyou":
        file = open("part2-4-50-64/WAI.txt")
        print(file.read())
        file.close()
    if usrinp == "whoami":
        print(os.getlogin())
    if usrinp == "ifconfig":
        os.system('ifconfig')
    if usrinp == "about_me":
        print(os.uname())
        #GAME_LIST
    if usrinp == "games":
        print("XO")
    if usrinp == "XO":
        board = list(range(1,10))

        def draw_board(board):
            print("-" * 13)
            for i in range(3):
                print("|", board[0+i*3], "|", board[1+i*3], "|", board[2+i*3], "|")
                print("-" * 13)

        def take_input(player_token):
            valid = False
            while not valid:
                player_answer = input("Where place " + player_token+"? ")
                try:
                    player_answer = int(player_answer)
                except:
                    print("Incorrect input!!!")
                    continue
                if player_answer >= 1 and player_answer <= 9:
                    if (str(board[player_answer-1]) not in "XO"):
                        board[player_answer-1] = player_token
                        valid = True
                    else:
                        print("Closed")
                else:
                    print("Incorrect input!")
        def check_win(board):
            win_coord = ((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
            for each in win_coord:
                if board[each[0]] == board[each[1]] == board[each[2]]:
                    return board[each[0]]
            return False
        def main(board):
            counter = 0
            win = False
            while not win:
                draw_board(board)
                if counter % 2 == 0:
                    take_input("X")
                else:
                    take_input("0")
                counter += 1
                if counter > 4:
                    tmp = check_win(board)
                    if tmp:
                        print(tmp, "You Win!")
                        win = True
                        break
                if counter == 9:
                    print("No anyone win!")
                    break
            draw_board(board)
        main(board)
#######################BIN_ALPHABET#############################
    if usrinp == "open_ba":
        print("--------------------------")
        print("Bin Alphabet")
        print("1. Russian")
        print("2. English")
        choise3 = input("Which alphabet i need show?_ ")
        if choise3 == "1":
            print("А - 11000000")
            print("Б - 11000001")
            print("В - 11000010")
            print("Г - 11000011")
            print("Д - 11000100")
            print("Е - 11000101")
            print("Ж - 11000110")
            print("З - 11000111")
            print("И - 11001000")
            print("К - 11001001")
            print("Л - 11001010")
            print("М - 11001011")
#######################THIS IS THE FUCKING CHAT########################
    if usrinp == "open_chat":
        os.system("cd part3-4-50-64 && python server.py")
######################THIS IS THE END OF FUCKING CHAT#######################
#============================DATABASE==========================
    if usrinp == "database":
        select = input("Type number of people_ ")
inputreading.close()
