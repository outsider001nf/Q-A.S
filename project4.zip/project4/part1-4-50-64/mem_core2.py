#IDENTIFICATION: memory controller
#DEVELOPER: outsider001
#TEAM: 404NotFound404
#DISCRIPTION: memory controller, needed for writing and reading data from memory files
#FUNCTION: writing all user input
file = open("memory_file2.txt")
print(file.read())
file.close()
