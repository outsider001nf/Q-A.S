#IDENTIFICATION: memory controller
#DEVELOPER: outsider001
#TEAM: 404NotFound404
#DISCRIPTION: memory controller, needed for writing and reading data from memory files
#FUNCTION: writing the opening of QAS
import datetime
now = datetime.datetime.now()
forwrite = now.strftime('%Y-%m-%d %H:%M:%S, day: %A')
file = open("memory_file1.txt", "w")
file.write(forwrite)
file.close()
file = open("memory_file1.txt", "r")
print(file.read())
file.close()
